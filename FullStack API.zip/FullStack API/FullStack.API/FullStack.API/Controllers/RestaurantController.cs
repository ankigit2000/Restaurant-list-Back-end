﻿using FullStack.API.Data;
using FullStack.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FullStack.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RestaurantController : Controller
    {
        private readonly RestaurantDbContext _restaurantDbContext;
        public RestaurantController(RestaurantDbContext restaurantDbContext)
        {
            _restaurantDbContext = restaurantDbContext;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllRestaurants()
        {
            var restaurants = await _restaurantDbContext.Restaurants.ToListAsync();
            return Ok(restaurants);
            
        }
        [HttpPost]
        public async Task<IActionResult> AddRestaurant([FromBody] Restaurant restaurantRequest)
        {
            restaurantRequest.id = Guid.NewGuid();
            await _restaurantDbContext.Restaurants.AddAsync(restaurantRequest);
            await _restaurantDbContext.SaveChangesAsync();
            return Ok(restaurantRequest);

        }
        [HttpGet]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> GetRestaurant([FromRoute] Guid Id)
        {
           var restaurant = await _restaurantDbContext.Restaurants.FirstOrDefaultAsync(x => x.id == Id);
            if (restaurant== null)
            {
                return NotFound();
            }
            return Ok(restaurant);
        }
        [HttpPut]
        [Route("{Id:Guid}")]
        public async Task<IActionResult> UpdateRestaurant([FromRoute] Guid Id, Restaurant updateRestaurantRequest)
        {
           var restaurant= await _restaurantDbContext.Restaurants.FindAsync(Id);
            if (restaurant == null)
            {
                return NotFound();

            }
            restaurant.restoName = updateRestaurantRequest.restoName;
            restaurant.location = updateRestaurantRequest.location;
            restaurant.specialities = updateRestaurantRequest.specialities;
            restaurant.additiionalFeatures = updateRestaurantRequest.additiionalFeatures;
            restaurant.menu = updateRestaurantRequest.menu;

            await _restaurantDbContext.SaveChangesAsync();
            return Ok(restaurant);

        }
        [HttpDelete]
        [Route("{Id:Guid}")]
        public async Task<IActionResult>DeleteRestaurant([FromRoute]Guid Id)
        {
            var restaurant = await _restaurantDbContext.Restaurants.FindAsync(Id);
            if (restaurant == null)
            {
                return NotFound();
            }
            _restaurantDbContext.Restaurants.Remove(restaurant);
            await _restaurantDbContext.SaveChangesAsync();
            return Ok(restaurant);
        }
    }
}
